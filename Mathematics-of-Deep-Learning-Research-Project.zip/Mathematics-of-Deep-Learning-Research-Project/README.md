# Mathematics-of-Deep-Learning-Research-Project
# Sam Fieldman sf3043, Zongmin Yin zy2437, Zvi Goldstein zsg2112

Convnet and Resnet models are defined in the model folder
Scripts for training Convnet, Resnet, and visualizing results are in the utils folder
Model definition and script for running single-hidden-layer DNN experiment is in the DNN_alpha_experiment folder
Convnet and Resnet models can be trained from corresponding .ipynb notebooks
Visualizations can be created from Alpha_scaling_visualizations.ipynb and Visualizations.ipynb